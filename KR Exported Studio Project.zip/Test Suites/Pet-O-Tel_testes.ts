<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Pet-O-Tel_testes</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>0227649c-4200-4611-8cab-d048b711edbb</testSuiteGuid>
   <testCaseLink>
      <guid>5ebb37fa-abd9-4afa-be03-278d08295a05</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Pet-O-Tel_testes/Registar conta</testCaseId>
   </testCaseLink><testCaseLink>
      <guid>a6c787f0-1f95-4530-8ac5-68627b58b835</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Pet-O-Tel_testes/Visualizar Serviços</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    